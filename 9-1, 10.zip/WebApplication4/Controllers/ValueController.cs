﻿using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;
using WebApplication4.Models;
using WebApplication4.Repo;

namespace WebApplication4.Controllers
{
    
        [Route("student")]
        [ApiController]
        public class StudentController : ControllerBase
        {
            private readonly IStudentRepo _studentRepo;
            public StudentController(IStudentRepo studentRepo)
            {
                _studentRepo = studentRepo;
            }
            [HttpPost( "Add")]

            public IActionResult AddStudent(StudentModel s)
            {
                _studentRepo.AddStudent(s);
                return Ok("Success");
            }
        [HttpPost("AddBulkStudent")]

        public IActionResult AddBulkStudent(List<StudentModel> students)
        {
            _studentRepo.AddBulkStudent(students);
            return Ok("Bulk addition successful");
        }
        [HttpPost("Get")]
            public List<StudentModel> GetStudents()
            {
                return _studentRepo.GetAllStudent();
            }
        [HttpPost("GetByBranch")]
        public List<StudentModel> GetStudentsByBranch([FromBody] string name)
        {
            return _studentRepo.GetAllStudentsByBranch(name);
        }
        [HttpPost("GetByLocation")]
        public List<StudentModel> GetStudentsByLocation([FromBody] string name)
        {   
            return _studentRepo.GetAllStudentsByLocation(name);
        }
        [HttpPost("GetByRollNo")]
        public List<StudentModel> GetStudentsByRoll([FromBody] int a)
        {
            return _studentRepo.GetStudentWithRollNo(a);
        }
        [HttpPost("RemoveByRollNo")]
        public IActionResult RemoveByRollNo([FromBody] int a)
        {
            _studentRepo.RemoveStudentByRoll(a);
            return Ok("Success");
        }
        [HttpPost("GetBloodGroupByRollNo")]
        public string GetBloodGroupByRollNo([FromBody] int a) 
        {
          return  _studentRepo.GetBloodGroupByRollNo(a);

        }
        [HttpPatch("UpdateStudent/{rollno}")]
        public IActionResult UpdateStudentDetails(int rollno, [FromBody] JsonPatchDocument patchDoc)
        {
            
             _studentRepo.UpdateStudent(rollno, patchDoc);
            return Ok("Success"); 
          
        }
    }
}
