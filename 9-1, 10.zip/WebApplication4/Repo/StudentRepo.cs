﻿using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using WebApplication4.Models;

namespace WebApplication4.Repo
{
         public interface IStudentRepo
    {
        List<StudentModel> GetAllStudent();
        void AddStudent(StudentModel s);
        List<StudentModel> GetAllStudentsByBranch(string s);
        List<StudentModel> GetAllStudentsByLocation(string s);
        List<StudentModel> GetStudentWithRollNo(int a);
        void RemoveStudentByRoll(int a);
        string GetBloodGroupByRollNo(int a);
        void AddBulkStudent( List<StudentModel> students);
        void UpdateStudent(int rollNo, JsonPatchDocument updatedStudent);
    }
    public class StudentRepo : IStudentRepo
    {
        private List<StudentModel> _L;
        public StudentRepo()
        {
            this._L = new List<StudentModel>();
        }
        public List<StudentModel> GetAllStudent()
        {
            List<StudentModel> l = new List<StudentModel>();
            foreach (StudentModel studentModel in _L)
            {
                l.Add(studentModel);
            }
            return l;
        }
        public void AddStudent(StudentModel s)
        {
            _L.Add(s);
        }
        public List<StudentModel> GetAllStudentsByBranch(string s)
        {
            List<StudentModel> l = new List<StudentModel>();
            foreach (StudentModel studentModel in _L)
            {
                if(studentModel.branch.Equals(s))
                l.Add(studentModel);
            }
            return l;
        }
        public List<StudentModel> GetAllStudentsByLocation(string s)
        {
            List<StudentModel> l = new List<StudentModel>();
            foreach (StudentModel studentModel in _L)
            {
                if (studentModel.location.Equals(s))
                    l.Add(studentModel);
            }
            return l;
        }
        public List<StudentModel> GetStudentWithRollNo(int a)
        {
            List<StudentModel> l = new List<StudentModel>();
            foreach (StudentModel studentModel in _L)
            {
                if (studentModel.rollno.Equals(a))
                    l.Add(studentModel);
            }
            return l;
        }
        public void RemoveStudentByRoll(int a)
        {
            _L.RemoveAll(studentModel => studentModel.rollno == a);
        }
        public string GetBloodGroupByRollNo(int rollno)
        {
            var student = _L.FirstOrDefault(s => s.rollno == rollno);
            if (student != null)
            {
                return student.bloodgroup; // Assuming 'bloodGroup' is a property in StudentModel
            }
            return null;
        }
        public void AddBulkStudent(List<StudentModel> L)
        {
            _L.AddRange(L);
        }
        public void UpdateStudent(int rollNo, JsonPatchDocument patchDoc)
        {
           foreach(StudentModel s in _L)
            {
                if(s.rollno == rollNo)
                {
                    patchDoc.ApplyTo(s);
                }
            }
           
        }

    }
}

    

