﻿namespace WebApplication4.Models
{
    public class StudentModel
    {
        public string name { get; set; }
        public int rollno { get; set; }
        public int marks { get; set; }
        public string branch { get; set; }
        public string location { get; set; }
       public string bloodgroup { get; set; }
        public string mobileno { get; set; }
        public StudentModel(string name, int rollno, int marks, string branch, string location, string bloodgroup, string mobileno)
        {
            this.name = name;
            this.rollno = rollno;
            this.marks = marks;
            this.branch = branch;
            this.location = location;
            this.bloodgroup = bloodgroup;
            this.mobileno = mobileno;
            this.bloodgroup = bloodgroup;
            this.mobileno = mobileno;
        }
    }
}
