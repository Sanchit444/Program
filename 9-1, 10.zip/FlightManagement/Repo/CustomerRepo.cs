﻿using FlightManagement.Models;
using Microsoft.AspNetCore.JsonPatch;

namespace FlightManagement.Repo
{
    public interface ICustomerRepo
    {
        void AddCustomer(CustomerModel customer);
        void AddBulkCustomers(List<CustomerModel> customers);
        List<CustomerModel> GetAllCustomers();
        CustomerModel GetCustomerById(int customerId);
        List<CustomerModel> GetCustomersByBloodGroup(string bloodGroup);
        void UpdateCustomer(int id,JsonPatchDocument j);
        void RemoveCustomerById(int customerId);
    }
    public class CustomerRepo : ICustomerRepo
    {
        private readonly List<CustomerModel> _customers; // Replace with actual database context or storage

        public CustomerRepo()
        {
            _customers = new List<CustomerModel>();
        }
        public void AddCustomer(CustomerModel customer)
        {
            _customers.Add(customer);
        }
        public void AddBulkCustomers(List<CustomerModel> customers)
        {
            _customers.AddRange(customers);
        }
        public List<CustomerModel> GetAllCustomers()
        {
            return _customers;
        }
        public CustomerModel GetCustomerById(int customerId)
        {
            return _customers.FirstOrDefault(c => c.CustomerID == customerId);
        }
        public List<CustomerModel> GetCustomersByBloodGroup(string bloodGroup)
        {
            return _customers.Where(c => c.BloodGroup.Equals(bloodGroup, StringComparison.OrdinalIgnoreCase)).ToList();
        }
        public void RemoveCustomerById(int customerId)
        {
            var customer = GetCustomerById(customerId);
            if (customer != null)
            {
                _customers.Remove(customer);
            }
        }
        public void UpdateCustomer(int customerId,JsonPatchDocument j)
        {
            foreach(var customer in _customers)
            {
                if(customer.CustomerID == customerId)
                {
                    j.ApplyTo(customer);
                }
            }
        }

    }

}
