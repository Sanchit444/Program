﻿using FlightManagement.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Microsoft.AspNetCore.JsonPatch;
namespace FlightManagement.Repo
{
    public interface IFlightRepo
    {
        void AddFlight(FlightModel flight);
        void AddBulkFlights(List<FlightModel> flights);
        List<FlightModel> GetAllFlights();
        FlightModel GetFlightById(int flightId);
        List<FlightModel> GetFlightsBySource(string source);
        int GetRemainingCapacity(int flightId);
        void UpdateFlight(int id,JsonPatchDocument j);
        //void UpdateCurrentlyBooked(int flightId, int passengersDelta);
        void RemoveFlightById(int flightId);
        
    }
    public class FlightRepo:IFlightRepo
    {
        private readonly List<FlightModel> _flights; // Replace with actual database context or storage

        public FlightRepo()
        {
            _flights = new List<FlightModel>();
        }
        public void AddFlight(FlightModel flight)
        {
            _flights.Add(flight);
        }
        public void AddBulkFlights(List<FlightModel> flights)
        {
            _flights.AddRange(flights);
        }
        public List<FlightModel> GetAllFlights()
        {
            return _flights;
        }
        public FlightModel GetFlightById(int flightId)
        {
            return _flights.FirstOrDefault(f => f.id == flightId);
        }
        public List<FlightModel> GetFlightsBySource(string source)
        {
            return _flights.Where(f => f.source.Equals(source, StringComparison.OrdinalIgnoreCase)).ToList();
        }
        public int GetRemainingCapacity(int flightId)
        {
            var flight = GetFlightById(flightId);
            if (flight == null)
                throw new ArgumentException("Flight not found");

            return flight.maxcapacity - flight.currentlybooked;
        }
        public void RemoveFlightById(int flightId)
        {
            var flight = GetFlightById(flightId);
            if (flight != null)
            {
                _flights.Remove(flight);
            }
        }
        public void UpdateFlight(int id, JsonPatchDocument j)
        {
            foreach (var flight in _flights)
            {
                if (flight.id == id)
                {
                    j.ApplyTo(flight);
                }
            }
        }
        }


    }

