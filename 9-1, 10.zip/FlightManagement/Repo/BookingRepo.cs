﻿using Newtonsoft.Json;
using FlightManagement.Models;
using FlightManagement.Repo;
namespace FlightManagement.Repo
{
    public interface IBookRepo
    {
        void AddBooking(BookingModel booking);
        void AddBulkBookings(List<BookingModel> bookings);
        List<BookingModel> GetAllBookings();
        List<BookingModel> GetBookingsWithDateRange(int startDate, int endDate);
        decimal GetEarningsWithDateRange(int startDate, int endDate);
        BookingModel GetBookingById(int bookingId);
        void RemoveBookingById(int bookingId);
        CustomerModel GetCustomerDetailsByBookingId(int bookingId);
        List<FlightModel> GetAllFlightsWithSourceByBookingId(int bookingID);
        bool AddPassengersToBooking(int bookingId, int numberOfPassengers);
    }
    public class BookingRepo : IBookRepo
    {
        private List<BookingModel> bookings;
        private readonly ICustomerRepo _customerRepository;
        private readonly IFlightRepo _flightRepository;
        public BookingRepo(ICustomerRepo customerRepository, IFlightRepo flightRepository)
        {
            _flightRepository = flightRepository;
            _customerRepository = customerRepository;

            LoadFlightsFromFile();
        }
        private void LoadFlightsFromFile()
        {
            string filePath = "bookings.json";
            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                bookings = JsonConvert.DeserializeObject<List<BookingModel>>(json);
            }
            else
            {
                bookings = new List<BookingModel>();
            }
        }
        private void SaveBookingsToFile()
        {
            string filePath = "bookings.json";
            string json = JsonConvert.SerializeObject(bookings, Formatting.Indented);
            File.WriteAllText(filePath, json);
        }
        public void AddBooking(BookingModel booking)
        {
            booking.BookingID = bookings.Count > 0 ? bookings.Max(b => b.BookingID) + 1 : 1;

            bookings.Add(booking);
            SaveBookingsToFile();
        }
        public void AddBulkBookings(List<BookingModel> bookingsToAdd)
        {
            foreach (var booking in bookingsToAdd)
            {
                booking.BookingID = bookings.Count > 0 ? bookings.Max(b => b.BookingID) + 1 : 1;
            }

            bookings.AddRange(bookingsToAdd);
            SaveBookingsToFile();
        }
        public List<BookingModel> GetAllBookings()
        {
            return bookings;
        }
        public List<BookingModel> GetBookingsWithDateRange(int startDate, int endDate)
        {
            return bookings.Where(b => b.BookedOnDate >= startDate && b.BookedOnDate <= endDate).ToList();
        }
        public decimal GetEarningsWithDateRange(int startDate, int endDate)
        {
            return bookings
                .Where(b => b.BookedOnDate >= startDate && b.BookedOnDate <= endDate)
                .Sum(b => b.TotalBookingCost);
        }
        public BookingModel GetBookingById(int bookingId)
        {
            return bookings.FirstOrDefault(b => b.BookingID == bookingId);
        }
        public void RemoveBookingById(int bookingId)
        {
            bookings.RemoveAll(b => b.BookingID == bookingId);
            SaveBookingsToFile();
        }
        public CustomerModel GetCustomerDetailsByBookingId(int bookingId)
        {
            var booking = bookings.FirstOrDefault(b => b.BookingID == bookingId);
            if (booking == null)
                return null;
            return _customerRepository.GetCustomerById(booking.CustomerID);
        }
        public List<FlightModel> GetAllFlightsWithSourceByBookingId(int bookingID)
        {
            var booking = bookings.FirstOrDefault(b => b.BookingID == bookingID);
            var flight = _flightRepository.GetFlightById(booking.FlightID);
            string source = flight.source;
            return _flightRepository.GetFlightsBySource(source);
        }
        public bool AddPassengersToBooking(int bookingId, int numberOfPassengers)
        {
            var booking = bookings.FirstOrDefault(b => b.BookingID == bookingId);
            if (booking == null)
                return false;
            var remainingCapacity = _flightRepository.GetRemainingCapacity(booking.FlightID);
            if (remainingCapacity >= numberOfPassengers)
            {
                booking.NumberOfPassengers += numberOfPassengers;
                SaveBookingsToFile();
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}
