﻿namespace FlightManagement.Models
{
    public class FlightModel
    {
    public int id { get; set; }
    public string source { get; set; }
    public string destination { get; set; }
    public string dateofjourney { get; set; }
    public string departuretime { get; set; }
    public string arrivaltime { get; set; }
    public int maxcapacity { get; set; }
    public int currentlybooked { get; set; }
    public int ticketcost { get; set; }
    public FlightModel() {
            this.id = id;
            this.source = source;
            this.destination = destination;
            this.dateofjourney = dateofjourney;
            this.currentlybooked = currentlybooked;
            this.ticketcost = ticketcost;
            this.arrivaltime = arrivaltime;
            this.maxcapacity = maxcapacity;
            this.departuretime = departuretime;
        }
    }
}
