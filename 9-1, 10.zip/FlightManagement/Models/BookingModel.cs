﻿namespace FlightManagement.Models
{
    public class BookingModel
    {
        public int BookingID { get; set; }
        public int CustomerID { get; set; }
        public int FlightID { get; set; }
        public int NumberOfPassengers { get; set; }
        public int BookedOnDate { get; set; }
        public decimal TotalBookingCost { get; set; }

        public BookingModel(int BookingID, int CustomerID, int FlightID, int NumberOfPassengers, int BookedOnDate, decimal TotalBookingCost)
        {
            this.BookingID = BookingID;
            this.CustomerID = CustomerID;
            this.FlightID = FlightID;
            this.TotalBookingCost = TotalBookingCost;
            this.NumberOfPassengers = NumberOfPassengers;
            this.BookedOnDate = BookedOnDate;

        }
    }
}
