﻿namespace FlightManagement.Models
{
    public class CustomerModel
    {
        public int CustomerID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Mobile { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public string BloodGroup { get; set; }
        public string PassportNumber { get; set; }
        public CustomerModel(int CustomerID, string Name,string Address,string Mobile,int age,string Gender,string BloodGroup,string PassportNumber)
        {
            this.CustomerID = CustomerID;
            this.Name = Name;
            this.Address = Address;
            this.Mobile = Mobile;
            this.Age = age;
            this.Gender = Gender;
            this.BloodGroup = BloodGroup;
            this.PassportNumber = PassportNumber;
        }
       
    }
}
