﻿using Microsoft.AspNetCore.Mvc;
using FlightManagement.Models;
using FlightManagement.Repo;
using System.Collections.Generic;
namespace FlightManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly IBookRepo _bookRepository;

        public BookingController(IBookRepo bookRepository)
        {
            _bookRepository = bookRepository;
        }
        [HttpPost("AddBooking")]
        public IActionResult AddBooking(BookingModel book)
        {
            _bookRepository.AddBooking(book);
            return Ok("Booking added successfully");
        }
        [HttpPost("AddBulkBooking")]
        public IActionResult AddBulkBooking(List<BookingModel> books)
        {
            _bookRepository.AddBulkBookings(books);
            return Ok("Booking added successfully");
        }
        [HttpGet("GetAllBookings")]
        public List<BookingModel> GetAllFlights()
        {
            return _bookRepository.GetAllBookings();
        }
        [HttpGet("GetBookingWithDateRange")]
        public List<BookingModel> GetBookingsWithDateRange(int startDate, int enddate)
        {
            return _bookRepository.GetBookingsWithDateRange(startDate, enddate);
        }
        [HttpGet("GetEarningWithDateRange")]
        public decimal GetEarningsWithDateRange(int startDate, int enddate)
        {
            return _bookRepository.GetEarningsWithDateRange(startDate, enddate);
        }
        [HttpGet("getbybookingId")]
        public BookingModel GetBookingById(int bookingId)
        {
            return _bookRepository.GetBookingById(bookingId);
        }
        [HttpDelete("removebybookingId")]
        public IActionResult RemoveBookingById(int bookingId)
        {
            _bookRepository.RemoveBookingById(bookingId);
            return Ok("Deleted");
        }
        [HttpGet("details")]
        public CustomerModel GetCustomerDetailsByBookingId(int bookingId)
        {
            return _bookRepository.GetCustomerDetailsByBookingId(bookingId);
        }
        [HttpPost("GetAllFlightsWithSourceByBookingId")]
        public List<FlightModel> GetAllFlightsWithSourceByBookingId([FromBody] int bookingID)
        {
            return _bookRepository.GetAllFlightsWithSourceByBookingId(bookingID);
        }
        [HttpPost("addpassengers")]
        public IActionResult AddPassengersToBooking(int bookingId, int numberOfPassengers)
        {
            if (_bookRepository.AddPassengersToBooking(bookingId, numberOfPassengers))
            {
                return Ok("Succesfully Added");
            }
            else
            {
                return Ok("Cannot add");
            }
        }







    }
}
