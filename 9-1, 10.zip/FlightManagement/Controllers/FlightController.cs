﻿using Microsoft.AspNetCore.Mvc;
using FlightManagement.Models;
using FlightManagement.Repo;
using Microsoft.AspNetCore.JsonPatch;

namespace FlightManagement.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class FlightController:ControllerBase
    {
        private readonly IFlightRepo _flightRepository;

        public FlightController(IFlightRepo flightRepository)
        {
            _flightRepository = flightRepository;
        }
        [HttpPost("AddFlight")]
        public IActionResult AddFlight(FlightModel flight)
        {
            _flightRepository.AddFlight(flight);
            return Ok("Flight added successfully");
        }
        [HttpPost("AddBulkFlights")]
        public IActionResult AddBulkFlights(List<FlightModel> flights)
        {
            _flightRepository.AddBulkFlights(flights);
            return Ok("Bulk addition of flights successful");
        }
        [HttpGet("GetAllFlights")]
        public List<FlightModel> GetAllFlights()
        {
            return _flightRepository.GetAllFlights();
        }
        [HttpGet("GetFlightWithID/{flightId}")]
        public FlightModel GetFlightWithID(int flightId)
        {
            var flight = _flightRepository.GetFlightById(flightId);
            if (flight == null)
                return null;
            return flight;
        }
        [HttpGet("GetFlightsWithSource")]
        public List<FlightModel> GetFlightsWithSource(string source)
        {
           return _flightRepository.GetFlightsBySource(source);
        }
        [HttpGet("GetRemainingCapacity/{flightId}")]
        public int GetRemainingCapacity(int flightId)
        {
            return _flightRepository.GetRemainingCapacity(flightId);
        }
        [HttpDelete("RemoveFlightById/{flightId}")]
        public IActionResult RemoveFlightById(int flightId)
        {
            _flightRepository.RemoveFlightById(flightId);
            return Ok("Flight removed successfully");
        }
        [HttpPatch("UpdateById")]
        public IActionResult UpdateFlight(int flightId, JsonPatchDocument j)
        {
            _flightRepository.UpdateFlight(flightId,j);
            return Ok("updated");
        }
    }
}
