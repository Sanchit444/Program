﻿using Microsoft.AspNetCore.Mvc;
using FlightManagement.Models;
using FlightManagement.Repo;
using System.Collections.Generic;
using Microsoft.AspNetCore.JsonPatch;

namespace FlightManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerRepo _customerRepository;
        public CustomerController(ICustomerRepo customerRepository)
        {
            _customerRepository = customerRepository;
        }
        [HttpPost("AddCustomer")]
        public IActionResult AddCustomer(CustomerModel customer)
        {
            _customerRepository.AddCustomer(customer);
            return Ok("Customer added successfully");
        }
        [HttpPost("AddBulkCustomers")]
        public IActionResult AddBulkCustomers(List<CustomerModel> customers)
        {
            _customerRepository.AddBulkCustomers(customers);
            return Ok("Bulk addition of customers successful");
        }
        [HttpGet("GetAllCustomers")]
        public List<CustomerModel> GetAllCustomers()
        {
            return _customerRepository.GetAllCustomers();
        }
        [HttpGet("GetAllCustomersByBlood")]
        public List<CustomerModel> GetCustomersByBloodGroup(string bloodGroup)
        {
            return _customerRepository.GetCustomersByBloodGroup(bloodGroup);
        }
        [HttpGet("GetAllCustomersById")]
        public CustomerModel GetCustomerById(int id)
        {
            return _customerRepository.GetCustomerById(id);
        }
        [HttpDelete("RemoveCustomer")]
        public IActionResult RemoveCustomerById(int id)
        {
            _customerRepository.RemoveCustomerById(id);
            return Ok("Succesfully Deleted");
        }
        [HttpPatch("UpdateCustomer")]
        public IActionResult Update(int id,JsonPatchDocument j)
        {
            _customerRepository.UpdateCustomer(id, j);
            return Ok("Updated");
        }
    }
}
