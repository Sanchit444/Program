using BankManagementSystem.Repo;
using Microsoft.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using BankManagementSystem.DAL;
using Newtonsoft.Json;
using BankManagementSystem;
using Microsoft.VisualBasic;
using static BankManagementSystem.Repo.ICustomerRepo;
using BankManagementSystem.Mapper;
using AutoMapper;
var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddScoped<ICustomerRepo, CustomerRepo>();
builder.Services.AddScoped<IAccountRepo, AccountRepo>();
builder.Services.AddScoped<Saving>();
builder.Services.AddScoped<Current>();
//builder.Services.
builder.Services.AddScoped<ITransactionRepo, TransactionRepo>();
builder.Services.AddScoped<ITransactionService, TransactionService>();
builder.Services.AddAutoMapper(typeof(ApplicationMappers));
builder.Services.AddScoped<Func<string, IAccount>>(serviceProvider => accountType =>
{
    var accountServiceDict = new Dictionary<string, Func<IAccount>>(StringComparer.OrdinalIgnoreCase)
    {
        { "saving", () => serviceProvider.GetRequiredService<Saving>() },
        { "current", () => serviceProvider.GetRequiredService<Current>() }
    };

    if (accountServiceDict.TryGetValue(accountType, out var serviceFactory))
    {
        return serviceFactory();
    }
    else throw new KeyNotFoundException($"Account service not found for account type: {accountType}");

});

//builder.Services.AddScoped<StrategyAccountService>(provider => (type) =>
//{
//    switch (type)
//    {
//        case accounttype.Saving: return provider.GetRequiredService<Saving>();
//        case accounttype.Current: return provider.GetRequiredService<Current>();
//        default: throw new NotImplementedException();
//    }
//});
builder.Services.AddControllers()
    .AddNewtonsoftJson(options =>
    {
        options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
        options.SerializerSettings.MaxDepth = 32; // Adjust the max depth if needed
    });
builder.Services.AddDbContext<BankContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("dbconn")));

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
