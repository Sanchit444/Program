﻿//using BankManagement.Models;
using BankManagementSystem.Repo;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.JsonPatch;
using BankManagementSystem.DTO;
using BankManagementSystem.DAL;
using Microsoft.AspNetCore.Http.Metadata;

[Route("api/[controller]")]
[ApiController]
public class CustomersController : ControllerBase
{
    private readonly ICustomerRepo _customerRepo;

    public CustomersController(ICustomerRepo customerRepo)
    {
        _customerRepo = customerRepo;
    }

    // POST: api/Customers/Add


    // DELETE: api/Customers/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteCustomer(int id)
    {
        var result = await _customerRepo.DeleteCustomer(id);
        if (result)
        {
            return Ok("Customer successfully deleted");
        }
        return NotFound("Customer not found");
    }
    [HttpGet("GetAllCustomer")]
    public List<Customer> GetAllCustomer()
    {
        return _customerRepo.GetAllCustomers();
    }
    [HttpPatch("UpdateByCustomerID")]
    public IActionResult UpdateCustomer(int id, JsonPatchDocument j)
    {
        _customerRepo.UpdateCustomer(id, j);
        return Ok("Success");
    }
    [HttpPost("AddCustomer")]
    public IActionResult Add(CustomerDTO customer)
    {
        try
        {
            _customerRepo.AddCustomer(customer);
            return Ok("Success");
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }

}
