﻿using BankManagementSystem.DAL;
using BankManagementSystem.Repo;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Principal;
using BankManagementSystem.DTO;
using Microsoft.AspNetCore.JsonPatch;
using static BankManagementSystem.Repo.ICustomerRepo;

[ApiController]
[Route("api/[controller]")]
public class AccountController : ControllerBase
{
    private readonly IAccountRepo _accountrepo;


    public AccountController(IAccountRepo accountrepo)
    {
        _accountrepo = accountrepo;

    }
    [HttpPost("Withdraw")]
    public async Task<IActionResult> Withdraw(int id, int amount)
    {

        try
        {
            await _accountrepo.Withdraw(id, amount);
            return Ok("Withdrawal successful.");
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }

    }
    [HttpPost("Deposit")]
    public async Task<IActionResult> Deposit(int accountId, decimal amount)
    {
        try
        {
            await _accountrepo.Deposit(accountId, amount);
            return Ok("success");
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }
    [HttpPost("Transfer")]
    public async Task<IActionResult> Transfer(int accountId, int destinationid, decimal amount)
    {
        try
        {
            await _accountrepo.TransferMoney(accountId, destinationid, amount);
            return Ok("success");
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }
    [HttpGet("TransactionSummary")]
    public async Task<List<Transaction>> GetTransactionSummary(int accountid, DateTime start, DateTime end)
    {
        return await _accountrepo.GetTransactionSummary(accountid, start, end);
    }
    [HttpPost("AddAccount")]
    public async Task<IActionResult> AddAccount(AccountDTO account)
    {
        try
        {
            await _accountrepo.AddAccount(account);
            return Ok("success");
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }
    [HttpGet("GetAllAccount")]
    public async Task<List<Account>> GetAllAccount()
    {
        return _accountrepo.GetAllAccounts();
    }

    [HttpGet("GetRemainingWitdrawalsToday")]
    public async Task<IActionResult> GetRemainingWithdrawalasToday(int accountid)
    {
        try
        {
            return Ok(await _accountrepo.GetRemainingWithdrawalsToday(accountid));
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }
    [HttpGet("GetRemainingNumberofWitdrawalsToday")]
    public async Task<IActionResult> GetRemainingNumberOfWithdrawalasToday(int accountid)
    {
        try
        {
            return Ok(await _accountrepo.GetNumberOfRemainingWithdrawalsToday(accountid));
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }
    [HttpDelete("DeleteAccount")]
    public async Task<IActionResult> DeleteAccount(int accountid)
    {
        try
        {
            await _accountrepo.DeleteAccount(accountid);
            return Ok("success");
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }
    [HttpPatch("UpdateByAccountID")]
    public IActionResult UpdateCustomer(int id, JsonPatchDocument j)
    {
        _accountrepo.UpdateAccount(id, j);
        return Ok("Success");
    }
    [HttpGet("GetCountOfAllAccount")]
    public IActionResult GetCountOfAllAccount()
    {
        try
        {
            return Ok(_accountrepo.GetcountofAllCount());
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }
    [HttpGet("CheckBalance")]
    public async Task<IActionResult> GetBalance(int id)
    {
        try
        {
            var balance = await _accountrepo.GetBalance(id);
            return Ok(balance);
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }
}
