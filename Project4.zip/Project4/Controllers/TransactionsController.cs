﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BankManagementSystem.DAL;
using BankManagementSystem.Repo;

namespace BankManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionsController : ControllerBase
    {

        private readonly ITransactionRepo _transactionrepo;

        public TransactionsController(ITransactionRepo transactionrepo)
        {
            _transactionrepo = transactionrepo;
        }
        [HttpPost("DeleteTransaction")]
        public async Task DeleteTransaction(int id)
        {
            await _transactionrepo.DeleteTransaction(id);
        }
    }
}
