﻿using BankManagementSystem.DTO;
using BankManagementSystem.DAL;
using AutoMapper;

namespace BankManagementSystem.Mapper
{
    public class ApplicationMappers:Profile
    {
        public ApplicationMappers() 
        {
            CreateMap<CustomerDTO, Customer>();
            CreateMap< Customer, CustomerDTO>();
            CreateMap<AccountDTO, Account>().ForMember(dest => dest.Balance, opt => opt.MapFrom(src => src.Amount));
            CreateMap<Account, AccountDTO>();
            
        }
        
    }
}
