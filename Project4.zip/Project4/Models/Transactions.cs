﻿namespace BankManagementSystem.Models
{
    public class Transactions
    {
        public int TransactionId { get; set; }
        public int FromAccountId { get; set; }
        public string TransactionType { get; set; }
        public decimal Amount { get; set; }
        public DateTime TransactionDate { get; set; }
    }
}
