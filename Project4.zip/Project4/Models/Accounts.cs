﻿namespace BankManagementSystem.Models
{
    public class Accounts
    {
        public int AccountId { get; set; }
        public int CustomerId { get; set; }
        public string AccountNumber { get; set; } = null!;
        public string AccountType { get; set; } = null!;
        public decimal? Balance { get; set; }
        public DateTime? OpeningDate { get; set; }
        public string? Ifsc { get; set; }
        public string? Branch { get; set; }
        public decimal? InterestRate { get; set; }
    }
}
