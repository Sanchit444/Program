﻿namespace BankManagementSystem.DTO
{
    public class AccountDTO
    {
        public int CustomerId { get; set; }
        public string AccountType { get; set; } 
        public decimal Amount { get; set; }

    }
}
