﻿using BankManagementSystem.DAL;
using Microsoft.EntityFrameworkCore;

namespace BankManagementSystem.Repo
{
    public interface ITransactionRepo
    {
        Task DeleteTransaction(int id);
    }
    public class TransactionRepo : ITransactionRepo
    {
        private readonly BankContext _context;
        private readonly IAccountRepo _accountRepo;

        public TransactionRepo(BankContext context, IAccountRepo accountrepo)
        {
            _context = context;
            _accountRepo = accountrepo;
        }
        public async Task DeleteTransaction(int id)
        {
           
            var transactions = await _context.Transactions
                .Where(t => t.TransactionId == id)
                .ToListAsync(); 

            if (transactions.Count == 0)
            {
                throw new Exception("No transaction found in database");
            }

            foreach (var transaction in transactions)
            {
                if (transaction.TransactionType == "Deposit")
                {
                    await _accountRepo.Withdraw(transaction.AccountId, transaction.Amount);
                }
                else if (transaction.TransactionType == "Withdraw")
                {
                    await _accountRepo.Deposit(transaction.AccountId, transaction.Amount);
                }

            }
           
            await _context.SaveChangesAsync();
        }
    }
}


