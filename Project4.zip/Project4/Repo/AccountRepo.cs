﻿using AutoMapper;
using BankManagementSystem.DAL;
using BankManagementSystem.DTO;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Diagnostics.Metrics;

namespace BankManagementSystem.Repo
{
    public interface IAccountRepo
    {
        Task AddAccount(AccountDTO accountobj);
        Task<bool> DeleteAccount(int accountId);
        List<Account> GetAllAccounts();
        Task Deposit(int accountId, decimal amount);
        Task Withdraw(int accountId, decimal amount);
        Task TransferMoney(int sourceId, int destinationId, decimal amount);
        Task<List<Transaction>> GetTransactionSummary(int accountId, DateTime startDate, DateTime endDate);
        Task<decimal> GetRemainingWithdrawalsToday(int accountid);
        Task<int> GetNumberOfRemainingWithdrawalsToday(int accountid);
        void UpdateAccount(int id, JsonPatchDocument j);
        Task<decimal> GetBalance(int accountid);
        int GetcountofAllCount();
    }
    public class AccountRepo : IAccountRepo
    {
        private readonly BankContext _context;
        private readonly ITransactionService _transactionService;
        private readonly Func<string, IAccount> _accountResolver;
        private readonly IMapper _mapper;
        public AccountRepo(BankContext context, ITransactionService transactionService, Func<string, IAccount> accountResolver, IMapper mapper)
        {
            _context = context;
            _transactionService = transactionService;
            _accountResolver = accountResolver;
            _mapper = mapper;
        }
        public async Task Deposit(int accountId, decimal amount)
        {
            var account = await _context.Accounts.FindAsync(accountId);
            if (account == null)
            {
                throw new ArgumentException("Account not found.");
            }
            account.Balance += amount;

            var lastTransactionId = await _context.Transactions
          .OrderByDescending(t => t.TransactionId)
           .Select(t => t.TransactionId)
           .FirstOrDefaultAsync();
            await _transactionService.AddTransaction(accountId, lastTransactionId + 1, "Deposit", amount, DateTime.Now);
            await _context.SaveChangesAsync();
        }
        public async Task AddAccount(AccountDTO account)
        {
            var accountobj = _mapper.Map<Account>(account);
            var accountInstance = _accountResolver(account.AccountType);
            if (account.Amount < accountInstance.minimumbalance)
            {
                throw new InvalidOperationException("Cannot create a  account. The amount is less than the minimum required balance.");
            }
            accountobj.OpeningDate = DateTime.Now;
            _context.Accounts.Add(accountobj);
            _context.SaveChanges();
            var lastTransactionId = await _context.Transactions
          .OrderByDescending(t => t.TransactionId)
           .Select(t => t.TransactionId)
           .FirstOrDefaultAsync();
            await _transactionService.AddTransaction(accountobj.AccountId, lastTransactionId + 1, "Deposit", account.Amount, DateTime.Now);
            await _context.SaveChangesAsync();
        }
        public List<Account> GetAllAccounts()
        {
            return _context.Accounts.ToList();
        }
        public void UpdateAccount(int id, JsonPatchDocument j)
        {
            var account = _context.Accounts.Find(id);
            if (account != null)
            {
                j.ApplyTo(account);
                _context.SaveChanges();
            }
        }
        public int GetcountofAllCount()
        {
            List<Account> l = new List<Account>();
            l = GetAllAccounts();
            return l.Count();
        }
        public async Task<bool> DeleteAccount(int accountId)
        {
            var account = await _context.Accounts.FindAsync(accountId);
            if (account == null)
            {
                return false;
            }

            var customerId = account.CustomerId;
            var customerAccounts = await _context.Accounts
                                                  .Where(a => a.CustomerId == customerId)
                                                  .ToListAsync();

            if (customerAccounts.Count == 1)
            {
                var customer = await _context.Customers.FindAsync(customerId);
                if (customer != null)
                {
                    _context.Customers.Remove(customer);
                }
            }
            _context.Accounts.Remove(account);
            await _context.SaveChangesAsync();
            return true;
        }
        public async Task Withdraw(int accountId, decimal amount)
        {
            var account = await _context.Accounts.FindAsync(accountId);
            if (account == null)
            {
                throw new ArgumentException("Account not found.");
            }
            var accountInstance = _accountResolver(account.AccountType);
            var newBalance = account.Balance - amount;
            if (newBalance < accountInstance.minimumbalance)
            {
                throw new InvalidOperationException("Cannot withdraw amount. The resulting balance is less than the minimum required balance.");
            }
            var withdrawals = await _context.Transactions
               .Where(t => t.AccountId == accountId && t.TransactionType == "Withdraw"  && t.TransactionDate.Date == DateTime.Now.Date)
               .SumAsync(t => t.Amount);
            if (withdrawals + amount > accountInstance.maxwithdrawamountperday)
            {
                throw new InvalidOperationException("Cannot withdraw amount. The daily withdrawal limit has been exceeded.");
            }
            int withdrawalsToday = await _context.Transactions
                .Where(t => t.AccountId == accountId && t.TransactionType == "Withdraw"  && t.TransactionDate.Date == DateTime.Now.Date)
                .CountAsync();
            if (withdrawalsToday == accountInstance.maxnumberwithdrawalsperday)
                throw new InvalidOperationException("Cannot withdraw amount. The daily withdrawal limit has been exceeded.");
            account.Balance = newBalance;
            var lastTransactionId = await _context.Transactions
          .OrderByDescending(t => t.TransactionId)
           .Select(t => t.TransactionId)
           .FirstOrDefaultAsync();
            await _transactionService.AddTransaction(accountId,lastTransactionId+1, "Withdraw", amount, DateTime.Now);
            await _context.SaveChangesAsync();
            // return "Success";
        }
        public async Task TransferMoney(int sourceId, int destinationId, decimal amount)
        {
            var account = await _context.Accounts.FindAsync(sourceId);
            var destinationaccount = await _context.Accounts.FindAsync(destinationId);
            if (account == null)
            {
                throw new ArgumentException("Account not found.");
            }
            var accountservice = _accountResolver(account.AccountType);

            var newBalance = account.Balance - amount;
            if (newBalance < accountservice.minimumbalance)
            {
                throw new InvalidOperationException("Cannot withdraw amount. The resulting balance is less than the minimum required balance.");
            }
            var withdrawals = await _context.Transactions
                .Where(t => t.AccountId == sourceId
                            && (t.TransactionType == "Withdraw")
                            && t.TransactionDate.Date == DateTime.Now.Date)
                .SumAsync(t => t.Amount);


            if (withdrawals + amount > accountservice.maxwithdrawamountperday)
            {
                throw new InvalidOperationException("Cannot withdraw amount. The daily withdrawal limit has been exceeded.");
            }
            int withdrawalsToday = await _context.Transactions
                .Where(t => t.AccountId == sourceId && (t.TransactionType == "Withdraw" ) && t.TransactionDate.Date == DateTime.Now.Date)
                .CountAsync();
            if (withdrawalsToday == accountservice.maxnumberwithdrawalsperday)
                throw new InvalidOperationException("Cannot withdraw amount. The daily withdrawal limit has been exceeded.");
            account.Balance = newBalance;
            destinationaccount.Balance = destinationaccount.Balance + amount;
            var lastTransactionId = await _context.Transactions
          .OrderByDescending(t => t.TransactionId)
           .Select(t => t.TransactionId)
           .FirstOrDefaultAsync();
            await _transactionService.AddTransaction(sourceId, lastTransactionId+1, "Withdraw", amount, DateTime.Now);
            await _transactionService.AddTransaction(destinationId, lastTransactionId + 1, "Deposit", amount, DateTime.Now);
            await _context.SaveChangesAsync();
        }
        public async Task<List<Transaction>> GetTransactionSummary(int accountId, DateTime startDate, DateTime endDate)
        {
            return await _context.Transactions
                                 .Where(t => t.AccountId == accountId && t.TransactionDate >= startDate && t.TransactionDate <= endDate)
                                 .ToListAsync();
        }
        public async Task<decimal> GetBalance(int accountid)
        {
            var account = await _context.Accounts.Where(t => t.AccountId == accountid).FirstOrDefaultAsync();
            if (account == null)
                throw new InvalidOperationException("account not found");
            return account.Balance;
        }
        public async Task<decimal> GetRemainingWithdrawalsToday(int accountid)
        {
            var account = await _context.Accounts.FindAsync(accountid);
            var accountInstance = _accountResolver(account.AccountType);
            int requirelimit = accountInstance.maxwithdrawamountperday;
            var withdrawals = await _context.Transactions
               .Where(t => t.AccountId == accountid && (t.TransactionType == "Withdraw") && t.TransactionDate.Date == DateTime.Now.Date)
               .SumAsync(t => t.Amount);
            return requirelimit - withdrawals;
        }
        public async Task<int> GetNumberOfRemainingWithdrawalsToday(int accountid)
        {
            var account = await _context.Accounts.FindAsync(accountid);
            var accountInstance = _accountResolver(account.AccountType);
            int requirenumberlimit = accountInstance.maxnumberwithdrawalsperday;
            var withdrawals = await _context.Transactions
               .Where(t => t.AccountId == accountid && (t.TransactionType == "Withdraw" ) && t.TransactionDate.Date == DateTime.Now.Date)
               .CountAsync();
            var val = requirenumberlimit - withdrawals;
            return val;
        }
    }
    public interface IAccount
    {
        int minimumbalance { get; set; }
        int maxwithdrawamountperday { get; set; }
        int maxnumberwithdrawalsperday { get; set; }
        decimal rateofinterestperday { get; set; }

    }
    public class Saving : IAccount
    {
        public int minimumbalance { get; set; } = 1000;
        public int maxwithdrawamountperday { get; set; } = 100000;
        public int maxnumberwithdrawalsperday { get; set; } = 3;
        public decimal rateofinterestperday { get; set; } = 4;

    }
    public class Current : IAccount
    {
        public int minimumbalance { get; set; } = 50000;
        public int maxwithdrawamountperday { get; set; } = 1000000;
        public int maxnumberwithdrawalsperday { get; set; } = 5;
        public decimal rateofinterestperday { get; set; } = 0.5m;
    }

}
