﻿//using BankManagement.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.JsonPatch;
using BankManagementSystem.DTO;
using BankManagementSystem.DAL;
using AutoMapper;
namespace BankManagementSystem.Repo
{
    public interface ICustomerRepo
    {
        Task AddCustomer(CustomerDTO customer);
        Task<bool> DeleteCustomer(int customerId);
        List<Customer> GetAllCustomers();
        void UpdateCustomer(int id, JsonPatchDocument j);

        public class CustomerRepo : ICustomerRepo
        {
            private readonly BankContext _context;
            private readonly IAccountRepo _accountRepo;
            private IMapper _mapper;
            public CustomerRepo(BankContext context, IMapper mapper, IAccountRepo accountRepo)
            {
                _context = context;
                _mapper = mapper;
                _accountRepo = accountRepo;
            }
            public async Task AddCustomer(CustomerDTO customerdto)
            {
                if (customerdto.AccountDTO == null)
                {
                    throw new ArgumentException("A customer must have at least one account.");
                }
                var customers = _mapper.Map<Customer>(customerdto);
                _context.Customers.Add(customers);
                _context.SaveChanges();
                int id = customers.CustomerId;
                customerdto.AccountDTO.CustomerId = id;
                await _accountRepo.AddAccount(customerdto.AccountDTO);
                await _context.SaveChangesAsync();
            }
            public async Task<bool> DeleteCustomer(int customerId)
            {
                var customer = await _context.Customers.FindAsync(customerId);
                if (customer == null)
                {
                    return false;
                }
                _context.Customers.Remove(customer);
                await _context.SaveChangesAsync();
                return true;
            }
            public List<Customer> GetAllCustomers()
            {
                return _context.Customers.ToList();
            }
            public void UpdateCustomer(int id, JsonPatchDocument j)
            {
                var customer = _context.Customers.Find(id);
                if (customer != null)
                {
                    j.ApplyTo(customer);
                    _context.SaveChanges();
                }
            }
        }

    }
}
