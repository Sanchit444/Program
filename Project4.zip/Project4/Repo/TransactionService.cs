﻿using AutoMapper;
using BankManagementSystem.DAL;
using BankManagementSystem.DTO;

namespace BankManagementSystem.Repo
{
    public interface ITransactionService
    {
        Task AddTransaction(int FromAccountId,int id,  string TransactionType, decimal amount, DateTime date);
        //Task RevertTransaction(int id, DateTime date);
    }

    public class TransactionService : ITransactionService
    {
        private readonly BankContext _context;
        
        private readonly IMapper _mapper;

        public TransactionService(BankContext context,IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
            
        }
        public async Task AddTransaction(int AccountId,int id, string TransactionType, decimal amount, DateTime date)
        {
            var transaction = new Transaction
            {
                TransactionId = id,
                AccountId = AccountId,
                Amount = amount,
                TransactionDate = date,
                TransactionType = TransactionType
            };
            _context.Transactions.Add(transaction);
            await _context.SaveChangesAsync();
        }
    }
}
