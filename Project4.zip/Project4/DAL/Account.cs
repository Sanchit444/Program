﻿using System;
using System.Collections.Generic;

namespace BankManagementSystem.DAL
{
    public partial class Account
    {
        public int AccountId { get; set; }
        public int CustomerId { get; set; }
        public string AccountType { get; set; } = null!;
        public decimal Balance { get; set; }
        public DateTime? OpeningDate { get; set; }

        public virtual Customer Customer { get; set; } = null!;
    }
}
