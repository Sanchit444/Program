﻿using System;
using System.Collections.Generic;

namespace BankManagementSystem.DAL
{
    public partial class Customer
    {
        public Customer()
        {
            Accounts = new HashSet<Account>();
        }

        public int CustomerId { get; set; }
        public string? Name { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string? Gender { get; set; }
        public string? Address { get; set; }
        public string? Country { get; set; }
        public string? PhoneNumber { get; set; }
        public string? EmailAddress { get; set; }
        public string? IdentificationType { get; set; }
        public string? AadhaarCard { get; set; }
        public string? PanCard { get; set; }
        public string? Occupation { get; set; }
        public string? MaritalStatus { get; set; }
        public string? Ckyc { get; set; }

        public virtual ICollection<Account> Accounts { get; set; }
    }
}
